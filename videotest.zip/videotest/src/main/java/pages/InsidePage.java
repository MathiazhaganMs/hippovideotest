package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class InsidePage extends BasePage{

    public InsidePage(WebDriver driver) {
        super(driver);
    }

    By plusIcon = By.id("ly_20000000004");
    By createVideo = By.xpath("(//section[contains(text(),'Create video')])[1]");
   


    public  InsidePage CreateVideo (){
    	click(plusIcon);
        click(createVideo);
        return this;
    }



   

    
}