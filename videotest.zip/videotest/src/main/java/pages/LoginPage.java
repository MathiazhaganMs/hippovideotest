package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class LoginPage extends BasePage{

    //*********Constructor*********
    public LoginPage(WebDriver driver) {
        super(driver);
    }

    //*********Web Elements*********
    By signuplink = By.xpath("//a[text()='START YOUR FREE TRIAL']");
    By usernamefield = By.id("user_email");
    By passwordfiled = By.id("user_password");
    By signupbutton = By.xpath("//input[@value='SIGNUP FOR FREE']");
    By signuptext = By.xpath("//label[text()='Where will you use Hippo Video?']");
    String baseURL = "https://www.hippovideo.io/";
    
    public  LoginPage Signingup (String username, String password){
    
    	click(signuplink);
        writeText(usernamefield,username);
        writeText(passwordfiled, password);
        click(signupbutton);
        return this;
    }
    
}