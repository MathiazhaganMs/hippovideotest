package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import sun.rmi.runtime.Log;

public class HomePage extends BasePage {


    public HomePage (WebDriver driver) {
        super(driver);
    }

 
    By businessButton = By.xpath("//span[text()='business']");
    By personalizedButton = By.xpath("//span[contains(text(),'Personalized marketing campaigns to boost conversions')]");
    By nextButton = By.id("Business-next-btn");
    By firstName = By.id("firstNameTxt");
    By companyName = By.id("companyNameTxt");
    By phoneNumber = By.id("phoneTxt");
    By getStarted = By.id("saveCompanyName");
    
    public HomePage selectFeature(){
    	click(businessButton);
    	click(personalizedButton);
    	click(nextButton);
    	writeText(firstName, "MSdhoni");
    	writeText(companyName, "IPLcompany");
    	writeText(phoneNumber, "7778889991");
    	click(getStarted);
        return this;
    }

  
}
