package tests;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;
import pages.InsidePage;

public class AllTests extends BaseTest {
	
    @Test (priority = 0)
    public void SignUpTest () {
  	
        LoginPage logPage = new LoginPage(driver);
        logPage.Signingup("iplt2020@gmail.com", "ipl@1243");
                
    }

    @Test (priority = 1)
    public void CreateVideoTest () {
        
        HomePage homePage = new HomePage(driver);
        InsidePage inPage = new InsidePage(driver);
        homePage.selectFeature();
        inPage.CreateVideo();
        
                
    }
}